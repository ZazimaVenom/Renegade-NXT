#if WITH_DEV_AUTOMATION_TESTS

#include "RenegadeHarvestPoint.h"
#include "RenegadeHarvesterCombatComponent.h"
#include "RenegadeRefineryDockPoint.h"
#include "RenegadeTeamCreditsManager.h"

#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "Misc/AutomationTest.h"

namespace RenegadeSupportTests
{
    struct FWorldFixture
    {
        UWorld* World = UWorld::CreateWorld(EWorldType::Game, false);

        ~FWorldFixture()
        {
            if (World)
            {
                World->DestroyWorld(false);
            }
        }

        AActor* CreateHarvester(const FName TeamId, const bool bDestroyed = false) const
        {
            AActor* Owner = World ? World->SpawnActor<AActor>() : nullptr;
            if (!Owner)
            {
                return nullptr;
            }

            URenegadeHarvesterCombatComponent* Combat = NewObject<URenegadeHarvesterCombatComponent>(Owner);
            Owner->AddInstanceComponent(Combat);
            Combat->TeamId = TeamId;
            Combat->bIsDestroyed = bDestroyed;
            Combat->RegisterComponent();
            // Reservation rules depend on component state, not AI timers or a running harvest cycle.
            return Owner;
        }
    };

    template <typename TPoint>
    bool CheckReservationContract(FAutomationTestBase& Test, FWorldFixture& Fixture)
    {
        TPoint* Point = Fixture.World ? Fixture.World->SpawnActor<TPoint>() : nullptr;
        AActor* FirstHarvester = Fixture.CreateHarvester(TEXT("GDI"));
        AActor* SecondHarvester = Fixture.CreateHarvester(TEXT("GDI"));
        AActor* EnemyHarvester = Fixture.CreateHarvester(TEXT("Nod"));
        AActor* DestroyedHarvester = Fixture.CreateHarvester(TEXT("GDI"), true);
        if (!Test.TestNotNull(TEXT("Point fixture exists"), Point)
            || !Test.TestNotNull(TEXT("First Harvester fixture exists"), FirstHarvester)
            || !Test.TestNotNull(TEXT("Second Harvester fixture exists"), SecondHarvester)
            || !Test.TestNotNull(TEXT("Enemy Harvester fixture exists"), EnemyHarvester)
            || !Test.TestNotNull(TEXT("Destroyed Harvester fixture exists"), DestroyedHarvester))
        {
            return false;
        }

        Point->TeamId = TEXT("GDI");
        Test.TestTrue(TEXT("Reservation fixture has authority"), Point->HasAuthority());
        Test.TestFalse(TEXT("Null actor cannot reserve a point"), Point->TryReserve(nullptr));
        Test.TestFalse(TEXT("Enemy Harvester is incompatible with the point"), Point->CanBeUsedByHarvester(EnemyHarvester));
        Test.TestFalse(TEXT("Enemy Harvester cannot reserve the point"), Point->TryReserve(EnemyHarvester));
        Test.TestFalse(TEXT("Destroyed Harvester is incompatible with the point"), Point->CanBeUsedByHarvester(DestroyedHarvester));
        Test.TestFalse(TEXT("Destroyed Harvester cannot reserve the point"), Point->TryReserve(DestroyedHarvester));
        Test.TestNull(TEXT("Rejected requests leave the point unreserved"), Point->ReservedHarvester.Get());

        Test.TestTrue(TEXT("A compatible live Harvester can reserve the point"), Point->TryReserve(FirstHarvester));
        Test.TestTrue(TEXT("The reservation belongs to the successful requester"), Point->ReservedHarvester == FirstHarvester);
        Test.TestTrue(TEXT("Repeating the owner's reservation is idempotent"), Point->TryReserve(FirstHarvester));
        Test.TestFalse(TEXT("Another Harvester cannot steal an exclusive reservation"), Point->TryReserve(SecondHarvester));
        Point->ReleaseReservation(SecondHarvester);
        Test.TestTrue(TEXT("Another Harvester cannot release the current owner's reservation"), Point->ReservedHarvester == FirstHarvester);

        // A runtime Details/Blueprint mode change must not strand the old exclusive owner.
        Point->bExclusiveReservation = false;
        Point->ReleaseReservation(FirstHarvester);
        Test.TestNull(TEXT("An existing reservation can be released after exclusivity is disabled"), Point->ReservedHarvester.Get());
        Test.TestTrue(TEXT("First Harvester can use a nonexclusive point"), Point->TryReserve(FirstHarvester));
        Test.TestTrue(TEXT("Second Harvester can also use a nonexclusive point"), Point->TryReserve(SecondHarvester));
        Test.TestNull(TEXT("Nonexclusive access does not create an exclusive reservation owner"), Point->ReservedHarvester.Get());
        Test.TestFalse(TEXT("Nonexclusive access still rejects enemy teams"), Point->TryReserve(EnemyHarvester));
        Test.TestFalse(TEXT("Nonexclusive access still rejects destroyed Harvesters"), Point->TryReserve(DestroyedHarvester));

        Point->bExclusiveReservation = true;
        Test.TestTrue(TEXT("Re-enabled exclusivity accepts a new owner"), Point->TryReserve(SecondHarvester));
        Test.TestTrue(TEXT("The new reservation belongs to the second Harvester"), Point->ReservedHarvester == SecondHarvester);
        Point->ReleaseReservation(nullptr);
        Test.TestNull(TEXT("Authoritative unconditional release clears the reservation"), Point->ReservedHarvester.Get());
        return true;
    }
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(
    FRenegadeTeamCreditsSaturationTest,
    "RenegadeNXT.Hardening.Support.CreditsSaturationSpendAndReset",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FRenegadeTeamCreditsSaturationTest::RunTest(const FString& Parameters)
{
    RenegadeSupportTests::FWorldFixture Fixture;
    ARenegadeTeamCreditsManager* Manager = Fixture.World ? Fixture.World->SpawnActor<ARenegadeTeamCreditsManager>() : nullptr;
    if (!TestNotNull(TEXT("Credit manager fixture exists"), Manager))
    {
        return false;
    }

    TestTrue(TEXT("Credit manager fixture has authority"), Manager->HasAuthority());
    const FName GDI(TEXT("GDI"));
    const FName Nod(TEXT("Nod"));
    Manager->SetTeamCredits(GDI, MAX_int32 - 5);
    TestEqual(TEXT("A deposit crossing int32 capacity saturates without erasing the bank"), Manager->AddTeamCredits(GDI, 10), MAX_int32);
    TestEqual(TEXT("A maximum deposit into a full bank remains saturated"), Manager->AddTeamCredits(GDI, MAX_int32), MAX_int32);
    TestEqual(TEXT("Case variants resolve the same team balance"), Manager->GetTeamCredits(TEXT("gdi")), MAX_int32);

    int32 RemainingCredits = -1;
    TestTrue(TEXT("The full saturated balance remains spendable"), Manager->TrySpendTeamCredits(GDI, MAX_int32, RemainingCredits));
    TestEqual(TEXT("Spending the whole bank reports zero remaining"), RemainingCredits, 0);
    TestEqual(TEXT("Spending the whole bank stores zero remaining"), Manager->GetTeamCredits(GDI), 0);

    Manager->SetTeamCredits(GDI, 100);
    Manager->SetTeamCredits(Nod, 30);
    TestEqual(TEXT("Negative deposits leave the bank unchanged"), Manager->AddTeamCredits(GDI, -50), 100);
    TestFalse(TEXT("Overspending is rejected"), Manager->TrySpendTeamCredits(GDI, 101, RemainingCredits));
    TestEqual(TEXT("Rejected spending reports the current balance"), RemainingCredits, 100);
    TestFalse(TEXT("Zero spending is rejected"), Manager->TrySpendTeamCredits(GDI, 0, RemainingCredits));
    TestFalse(TEXT("Negative spending cannot mint credits"), Manager->TrySpendTeamCredits(GDI, -50, RemainingCredits));
    TestEqual(TEXT("Invalid spending leaves the bank unchanged"), Manager->GetTeamCredits(GDI), 100);
    TestTrue(TEXT("A valid purchase debits the requested amount"), Manager->TrySpendTeamCredits(GDI, 35, RemainingCredits));
    TestEqual(TEXT("Successful spending reports the new balance"), RemainingCredits, 65);
    TestEqual(TEXT("Successful spending stores the new balance"), Manager->GetTeamCredits(GDI), 65);
    TestEqual(TEXT("Purchases do not change another team's bank"), Manager->GetTeamCredits(Nod), 30);

    const int32 TeamCount = Manager->TeamCredits.Num();
    TestEqual(TEXT("An unnamed team cannot receive credits"), Manager->AddTeamCredits(NAME_None, 10), 0);
    TestEqual(TEXT("Rejected unnamed-team deposits do not create a bank"), Manager->TeamCredits.Num(), TeamCount);
    Manager->ResetAllTeamCredits();
    TestEqual(TEXT("Reset clears the GDI balance"), Manager->GetTeamCredits(GDI), 0);
    TestEqual(TEXT("Reset clears the Nod balance"), Manager->GetTeamCredits(Nod), 0);
    TestEqual(TEXT("Reset preserves existing team entries"), Manager->TeamCredits.Num(), TeamCount);
    TestEqual(TEXT("A reset bank accepts later income"), Manager->AddTeamCredits(GDI, 25), 25);
    return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(
    FRenegadeHarvestReservationTest,
    "RenegadeNXT.Hardening.Support.HarvestReservationContract",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FRenegadeHarvestReservationTest::RunTest(const FString& Parameters)
{
    RenegadeSupportTests::FWorldFixture Fixture;
    return RenegadeSupportTests::CheckReservationContract<ARenegadeHarvestPoint>(*this, Fixture);
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(
    FRenegadeDockReservationTest,
    "RenegadeNXT.Hardening.Support.DockReservationContract",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FRenegadeDockReservationTest::RunTest(const FString& Parameters)
{
    RenegadeSupportTests::FWorldFixture Fixture;
    return RenegadeSupportTests::CheckReservationContract<ARenegadeRefineryDockPoint>(*this, Fixture);
}

#endif // WITH_DEV_AUTOMATION_TESTS
