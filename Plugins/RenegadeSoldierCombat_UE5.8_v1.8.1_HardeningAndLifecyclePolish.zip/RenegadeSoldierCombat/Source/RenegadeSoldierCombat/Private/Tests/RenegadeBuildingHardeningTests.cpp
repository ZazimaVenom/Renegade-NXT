#if WITH_DEV_AUTOMATION_TESTS

#include "RenegadeBuildingCombatComponent.h"
#include "RenegadeHarvesterCombatComponent.h"

#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "GameFramework/Character.h"
#include "GameFramework/DamageType.h"
#include "Misc/AutomationTest.h"

#include <limits>

namespace RenegadeBuildingTests
{
    struct FWorldFixture
    {
        UWorld* World = UWorld::CreateWorld(EWorldType::Game, false);

        ~FWorldFixture()
        {
            if (World)
            {
                World->DestroyWorld(false);
            }
        }

        URenegadeBuildingCombatComponent* CreateBuilding(const bool bBeginPlay = true) const
        {
            AActor* Owner = World ? World->SpawnActor<AActor>() : nullptr;
            if (!Owner)
            {
                return nullptr;
            }

            URenegadeBuildingCombatComponent* Building = NewObject<URenegadeBuildingCombatComponent>(Owner);
            Owner->AddInstanceComponent(Building);
            Building->bAutoStartDefenseOnBeginPlay = false;
            Building->bAutoSpawnHarvesterOnBeginPlay = false;
            Building->RegisterComponent();
            if (bBeginPlay)
            {
                Owner->DispatchBeginPlay();
            }
            return Building;
        }
    };
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(
    FRenegadeBuildingFiniteHealthTest,
    "RenegadeNXT.Hardening.Building.FiniteHealthAndDamage",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FRenegadeBuildingFiniteHealthTest::RunTest(const FString& Parameters)
{
    RenegadeBuildingTests::FWorldFixture Fixture;
    URenegadeBuildingCombatComponent* Building = Fixture.CreateBuilding();
    if (!TestNotNull(TEXT("Building fixture exists"), Building))
    {
        return false;
    }

    const float NaN = std::numeric_limits<float>::quiet_NaN();
    const float Infinity = std::numeric_limits<float>::infinity();
    Building->SetBuildingHealth(500.0f);
    Building->SetBuildingHealth(NaN);
    Building->RepairBuilding(Infinity);
    Building->RestoreBuilding(NaN);
    TestEqual(TEXT("Invalid health commands leave health unchanged"), Building->CurrentHealth, 500.0f);

    AActor* Owner = Building->GetOwner();
    Owner->OnTakeAnyDamage.Broadcast(Owner, NaN, GetDefault<UDamageType>(), nullptr, nullptr);
    Owner->OnTakeAnyDamage.Broadcast(Owner, Infinity, GetDefault<UDamageType>(), nullptr, nullptr);
    Building->HealthSettings.IncomingDamageMultiplier = NaN;
    Owner->OnTakeAnyDamage.Broadcast(Owner, 100.0f, GetDefault<UDamageType>(), nullptr, nullptr);
    TestEqual(TEXT("Non-finite damage and multipliers are ignored"), Building->CurrentHealth, 500.0f);

    Building->HealthSettings.MaximumHealth = Infinity;
    Building->RestoreBuilding();
    TestEqual(TEXT("Invalid maximum health uses the normal finite default"), Building->CurrentHealth, 1000.0f);
    TestEqual(TEXT("Health percentage stays bounded"), Building->GetHealthPercent(), 1.0f);

    Building->HealthSettings.MaximumHealth = TNumericLimits<float>::Max();
    Building->SetBuildingHealth(TNumericLimits<float>::Max() * 0.5f);
    Building->RepairBuilding(TNumericLimits<float>::Max());
    TestEqual(TEXT("Large finite repairs cap at maximum health"), Building->CurrentHealth, TNumericLimits<float>::Max());
    Building->HealthSettings.IncomingDamageMultiplier = 2.0f;
    Owner->OnTakeAnyDamage.Broadcast(Owner, TNumericLimits<float>::Max(), GetDefault<UDamageType>(), nullptr, nullptr);
    TestTrue(TEXT("Finite damage whose product exceeds float range still destroys the building"), Building->bIsDestroyed);
    TestEqual(TEXT("Destroyed health is finite and zero"), Building->CurrentHealth, 0.0f);
    return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(
    FRenegadeBuildingRestoreLifetimeTest,
    "RenegadeNXT.Hardening.Building.RestoreCancelsOwnedDestruction",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FRenegadeBuildingRestoreLifetimeTest::RunTest(const FString& Parameters)
{
    RenegadeBuildingTests::FWorldFixture Fixture;
    URenegadeBuildingCombatComponent* Building = Fixture.CreateBuilding();
    if (!TestNotNull(TEXT("Building fixture exists"), Building))
    {
        return false;
    }

    AActor* Owner = Building->GetOwner();
    Owner->SetLifeSpan(9.0f);
    Building->RestoreBuilding();
    TestTrue(TEXT("Ordinary restore preserves a lifespan owned by external gameplay"), Owner->GetLifeSpan() > 0.0f);
    Owner->SetLifeSpan(0.0f);

    Building->HealthSettings.bDestroyOwnerActorOnZeroHealth = true;
    Building->ForceDestroyBuilding(nullptr);
    TestTrue(TEXT("Destruction queues owner removal"), Owner->GetLifeSpan() > 0.0f);
    Building->RestoreBuilding(250.0f);
    TestTrue(TEXT("Restored building is operational"), Building->IsBuildingOperational());
    TestEqual(TEXT("Restore cancels the queued building destruction lifespan"), Owner->GetLifeSpan(), 0.0f);
    TestEqual(TEXT("Requested restored health is retained"), Building->CurrentHealth, 250.0f);
    return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(
    FRenegadeBuildingLowHealthRegressionTest,
    "RenegadeNXT.Hardening.Building.LowHealthRepairContract",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FRenegadeBuildingLowHealthRegressionTest::RunTest(const FString& Parameters)
{
    RenegadeBuildingTests::FWorldFixture Fixture;
    URenegadeBuildingCombatComponent* Building = Fixture.CreateBuilding();
    if (!TestNotNull(TEXT("Building fixture exists"), Building))
    {
        return false;
    }

    Building->SetBuildingHealth(250.0f);
    TestTrue(TEXT("A quarter health enters low health"), Building->bIsLowHealth);
    Building->RepairBuilding(30.0f);
    TestTrue(TEXT("Small repair retains hysteresis state"), Building->bIsLowHealth);
    Building->RepairBuilding(21.0f);
    TestFalse(TEXT("Repair above recovery threshold clears low health"), Building->bIsLowHealth);
    Building->HealthSettings.bAllowRepairAfterDestroyed = false;
    Building->ForceDestroyBuilding(nullptr);
    Building->RepairBuilding(500.0f);
    TestTrue(TEXT("Repair respects the disabled destroyed-building repair setting"), Building->bIsDestroyed);
    Building->RestoreBuilding();
    TestTrue(TEXT("Explicit authoritative restoration remains available"), Building->IsBuildingOperational());
    return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(
    FRenegadeRefineryStaleNotificationTest,
    "RenegadeNXT.Hardening.Building.RefineryIgnoresStaleNotifications",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FRenegadeRefineryStaleNotificationTest::RunTest(const FString& Parameters)
{
    RenegadeBuildingTests::FWorldFixture Fixture;
    URenegadeBuildingCombatComponent* Building = Fixture.CreateBuilding();
    if (!TestNotNull(TEXT("Building fixture exists"), Building))
    {
        return false;
    }

    Building->BuildingType = ERenegadeBuildingType::Refinery;
    Building->bEnableHarvesterSpawner = true;
    Building->HarvesterCharacterClass = ACharacter::StaticClass();
    Building->HarvesterRespawnDelaySeconds = 0.0f;
    Building->bEnsureSpawnedHarvesterHasAIController = false;
    Building->bAdoptExistingHarvesterOnBeginPlay = false;
    Building->bEnforceSingleActiveHarvesterPerTeam = false;
    Building->bAutoFindHarvesterHarvestPoint = false;
    Building->bAutoFindHarvesterRefineryDockPoint = false;

    Building->NotifyHarvesterDestroyed(nullptr);
    TestNull(TEXT("Null notification does not create a Harvester"), Building->ActiveHarvester.Get());
    AActor* StaleHarvester = Fixture.World->SpawnActor<AActor>();
    if (!TestNotNull(TEXT("Stale notification fixture exists"), StaleHarvester))
    {
        return false;
    }
    Building->NotifyHarvesterDestroyed(StaleHarvester);
    TestNull(TEXT("Unrelated notification does not create a Harvester"), Building->ActiveHarvester.Get());

    // Verify that a duplicate death notification cannot create a second respawn request.
    Building->bEnableHarvesterSpawner = false;
    Building->ActiveHarvester = StaleHarvester;
    Building->NotifyHarvesterDestroyed(StaleHarvester);
    TestNull(TEXT("The current Harvester is cleared by its death notification"), Building->ActiveHarvester.Get());
    Building->bEnableHarvesterSpawner = true;
    Building->NotifyHarvesterDestroyed(StaleHarvester);
    TestNull(TEXT("Repeated notification remains ignored after the first is consumed"), Building->ActiveHarvester.Get());
    return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(
    FRenegadeRefinerySharedHarvesterTest,
    "RenegadeNXT.Hardening.Building.SharedHarvesterPreservesRefineryRoute",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FRenegadeRefinerySharedHarvesterTest::RunTest(const FString& Parameters)
{
    RenegadeBuildingTests::FWorldFixture Fixture;
    URenegadeBuildingCombatComponent* FirstRefinery = Fixture.CreateBuilding();
    URenegadeBuildingCombatComponent* SecondRefinery = Fixture.CreateBuilding();
    ACharacter* Harvester = Fixture.World ? Fixture.World->SpawnActor<ACharacter>() : nullptr;
    if (!TestNotNull(TEXT("First Refinery exists"), FirstRefinery)
        || !TestNotNull(TEXT("Second Refinery exists"), SecondRefinery)
        || !TestNotNull(TEXT("Harvester fixture exists"), Harvester))
    {
        return false;
    }

    URenegadeHarvesterCombatComponent* HarvesterCombat = NewObject<URenegadeHarvesterCombatComponent>(Harvester);
    Harvester->AddInstanceComponent(HarvesterCombat);
    HarvesterCombat->RegisterComponent();
    HarvesterCombat->SetTeamId(TEXT("GDI"));
    HarvesterCombat->SetOwningRefinery(FirstRefinery);
    // Visibility is cosmetic and must not defeat the one-operational-Harvester rule.
    Harvester->SetActorHiddenInGame(true);

    SecondRefinery->BuildingType = ERenegadeBuildingType::Refinery;
    SecondRefinery->bEnableHarvesterSpawner = true;
    SecondRefinery->HarvesterCharacterClass = ACharacter::StaticClass();
    SecondRefinery->bEnsureSpawnedHarvesterHasAIController = false;
    SecondRefinery->bAdoptExistingHarvesterOnBeginPlay = false;
    SecondRefinery->bAutoFindHarvesterHarvestPoint = false;
    SecondRefinery->bAutoFindHarvesterRefineryDockPoint = false;

    TestTrue(TEXT("Second same-team Refinery shares the existing Harvester"), SecondRefinery->SpawnHarvesterNow() == Harvester);
    TestTrue(TEXT("Existing operational Refinery retains the route assignment"), HarvesterCombat->GetOwningRefinery() == FirstRefinery);
    SecondRefinery->SetTeamId(TEXT("Nod"));
    TestEqual(TEXT("Changing the sharing Refinery team does not capture another Refinery's Harvester"), HarvesterCombat->TeamId, FName(TEXT("GDI")));
    TestNull(TEXT("Changing teams releases the incompatible shared Harvester"), SecondRefinery->ActiveHarvester.Get());
    SecondRefinery->SetTeamId(TEXT("GDI"));
    TestTrue(TEXT("Returning to the original team can adopt the same Harvester"), SecondRefinery->SpawnHarvesterNow() == Harvester);

    // DestroyComponent drives normal EndPlay on this already-begun component.
    SecondRefinery->DestroyComponent();
    TestFalse(TEXT("Ended Refinery releases its Harvester destruction delegate"), Harvester->OnDestroyed.IsBound());
    return true;
}

#endif // WITH_DEV_AUTOMATION_TESTS
