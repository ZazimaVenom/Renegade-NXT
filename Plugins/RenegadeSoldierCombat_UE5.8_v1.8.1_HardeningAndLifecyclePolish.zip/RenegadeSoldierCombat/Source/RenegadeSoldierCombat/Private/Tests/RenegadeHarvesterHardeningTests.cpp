#include "RenegadeHarvesterCombatComponent.h"

#if WITH_DEV_AUTOMATION_TESTS

#include "RenegadeTeamCreditsManager.h"
#include "Components/SceneComponent.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "Misc/AutomationTest.h"

#include <limits>

namespace RenegadeHarvesterHardeningTests
{
    struct FScopedWorld
    {
        UWorld* World = UWorld::CreateWorld(EWorldType::Game, false);

        ~FScopedWorld()
        {
            if (World)
            {
                World->DestroyWorld(false);
            }
        }

        URenegadeHarvesterCombatComponent* CreateHarvester() const
        {
            AActor* Owner = World ? World->SpawnActor<AActor>() : nullptr;
            if (!Owner)
            {
                return nullptr;
            }
            USceneComponent* Root = NewObject<USceneComponent>(Owner);
            Owner->AddInstanceComponent(Root);
            Owner->SetRootComponent(Root);
            Root->RegisterComponent();

            URenegadeHarvesterCombatComponent* Harvester = NewObject<URenegadeHarvesterCombatComponent>(Owner);
            Owner->AddInstanceComponent(Harvester);
            Harvester->RegisterComponent();
            return Harvester;
        }

        USceneComponent* CreateBody(AActor* Owner, const FRotator& Rotation) const
        {
            USceneComponent* Body = NewObject<USceneComponent>(Owner);
            Owner->AddInstanceComponent(Body);
            Body->SetupAttachment(Owner->GetRootComponent());
            Body->SetRelativeRotation(Rotation);
            Body->RegisterComponent();
            return Body;
        }
    };
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FRenegadeHarvesterCargoHardeningTest,
    "RenegadeNXT.Hardening.Harvester.CargoAndBankBounds",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FRenegadeHarvesterCargoHardeningTest::RunTest(const FString& Parameters)
{
    (void)Parameters;
    RenegadeHarvesterHardeningTests::FScopedWorld Fixture;
    URenegadeHarvesterCombatComponent* Harvester = Fixture.CreateHarvester();
    if (!TestNotNull(TEXT("Harvester fixture"), Harvester))
    {
        return false;
    }

    Harvester->EconomySettings.CargoCapacity = 100.0f;
    Harvester->SetCurrentCargo(25.0f);
    Harvester->SetCurrentCargo(std::numeric_limits<float>::quiet_NaN());
    TestEqual(TEXT("NaN cargo is rejected"), Harvester->CurrentCargo, 25.0f);
    Harvester->AddHarvestedCargo(std::numeric_limits<float>::infinity());
    TestEqual(TEXT("Infinite harvest amount is rejected"), Harvester->CurrentCargo, 25.0f);
    Harvester->AddHarvestedCargo(std::numeric_limits<float>::max());
    TestEqual(TEXT("Large finite harvest saturates at capacity"), Harvester->CurrentCargo, 100.0f);
    TestEqual(TEXT("NaN deposit is rejected"), Harvester->DepositCargoToTeamCredits(std::numeric_limits<float>::quiet_NaN()), 0);
    TestEqual(TEXT("Rejected deposit preserves cargo"), Harvester->CurrentCargo, 100.0f);

    ARenegadeTeamCreditsManager* Manager = Harvester->GetTeamCreditsManager();
    if (!TestNotNull(TEXT("Team bank fixture"), Manager))
    {
        return false;
    }
    Harvester->EconomySettings.CreditsPerCargoUnit = 0.5f;
    TestEqual(TEXT("First half-credit is retained"), Harvester->DepositCargoToTeamCredits(1.0f), 0);
    TestEqual(TEXT("Second half-credit combines with remainder"), Harvester->DepositCargoToTeamCredits(1.0f), 1);
    TestEqual(TEXT("Fractional deposits debit their cargo once"), Harvester->CurrentCargo, 98.0f);
    TestEqual(TEXT("Fractional deposits credit the team once"), Manager->GetTeamCredits(Harvester->TeamId), 1);

    Manager->SetTeamCredits(Harvester->TeamId, MAX_int32 - 5);
    Harvester->EconomySettings.CreditsPerCargoUnit = 1.0f;
    Harvester->SetCurrentCargo(100.0f);
    TestEqual(TEXT("Deposit respects the bank's remaining capacity"), Harvester->DepositCargoToTeamCredits(), 5);
    TestEqual(TEXT("Team bank does not overflow"), Manager->GetTeamCredits(Harvester->TeamId), MAX_int32);
    TestEqual(TEXT("Overflow cargo is preserved"), Harvester->CurrentCargo, 95.0f);
    TestEqual(TEXT("Full bank rejects another deposit"), Harvester->DepositCargoToTeamCredits(), 0);
    TestEqual(TEXT("Full bank leaves cargo untouched"), Harvester->CurrentCargo, 95.0f);
    return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FRenegadeHarvesterPresentationHardeningTest,
    "RenegadeNXT.Hardening.Harvester.PresentationRefreshAndLifecycle",
    EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FRenegadeHarvesterPresentationHardeningTest::RunTest(const FString& Parameters)
{
    (void)Parameters;
    RenegadeHarvesterHardeningTests::FScopedWorld Fixture;
    URenegadeHarvesterCombatComponent* Harvester = Fixture.CreateHarvester();
    if (!TestNotNull(TEXT("Harvester fixture"), Harvester))
    {
        return false;
    }

    const FRotator AuthoredRotation(5.0f, 20.0f, -7.0f);
    USceneComponent* Body = Fixture.CreateBody(Harvester->GetOwner(), AuthoredRotation);
    Body->ComponentTags.Add(Harvester->GroundAlignmentVisualComponentTag);
    Harvester->SetRuntimeGroundAlignmentVisualComponent(Body);
    for (int32 Refresh = 0; Refresh < 3; ++Refresh)
    {
        // Simulate the runtime terrain correction before rebuilding presentation.
        Body->SetRelativeRotation(FRotator(13.0f, 20.0f, 11.0f));
        Harvester->RefreshHarvesterPresentation();
        TestTrue(TEXT("Refresh restores the authored body rotation without accumulating slope tilt"),
            Body->GetRelativeRotation().Equals(AuthoredRotation, 0.001f));
    }

    USceneComponent* ReplacementBody = Fixture.CreateBody(Harvester->GetOwner(), FRotator::ZeroRotator);
    Body->SetRelativeRotation(FRotator(13.0f, 20.0f, 11.0f));
    Harvester->SetRuntimeGroundAlignmentVisualComponent(ReplacementBody);
    TestTrue(TEXT("Changing the runtime body restores the old body"), Body->GetRelativeRotation().Equals(AuthoredRotation, 0.001f));
    TestTrue(TEXT("The replacement body is selected"), Harvester->GetGroundAlignmentVisualComponent() == ReplacementBody);

    // These bindings reproduce Blueprint lifecycle listeners that call the same command again.
    Harvester->OnHarvestingStarted.AddDynamic(Harvester, &URenegadeHarvesterCombatComponent::StartHarvesting);
    Harvester->OnHarvestingEnded.AddDynamic(Harvester, &URenegadeHarvesterCombatComponent::EndHarvesting);
    Harvester->StartHarvesting();
    TestTrue(TEXT("A reentrant start stays in the harvesting state"), Harvester->LifecycleState == ERenegadeHarvesterLifecycleState::Harvesting);
    Harvester->EndHarvesting();
    TestTrue(TEXT("A reentrant end advances to the return phase once"), Harvester->LifecycleState == ERenegadeHarvesterLifecycleState::ReturningToRefinery);
    return true;
}

#endif // WITH_DEV_AUTOMATION_TESTS
