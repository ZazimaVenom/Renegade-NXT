#include "RenegadeTeamCreditsManager.h"

#include "Net/UnrealNetwork.h"

ARenegadeTeamCreditsManager::ARenegadeTeamCreditsManager()
{
    bReplicates = true;
    bAlwaysRelevant = true;
    NetDormancy = DORM_Never;
    SetReplicateMovement(false);
}

void ARenegadeTeamCreditsManager::BeginPlay()
{
    Super::BeginPlay();

    LastObservedCredits.Reset();
    for (const FRenegadeTeamCreditEntry& Entry : TeamCredits)
    {
        LastObservedCredits.Add(Entry.TeamId, Entry.Credits);
    }
}

void ARenegadeTeamCreditsManager::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);
    DOREPLIFETIME(ARenegadeTeamCreditsManager, TeamCredits);
}

const FRenegadeTeamCreditEntry* ARenegadeTeamCreditsManager::FindEntry(const FName TeamId) const
{
    return TeamCredits.FindByPredicate([TeamId](const FRenegadeTeamCreditEntry& Entry)
    {
        return Entry.TeamId.IsEqual(TeamId, ENameCase::IgnoreCase);
    });
}

FRenegadeTeamCreditEntry* ARenegadeTeamCreditsManager::FindMutableEntry(const FName TeamId)
{
    return TeamCredits.FindByPredicate([TeamId](const FRenegadeTeamCreditEntry& Entry)
    {
        return Entry.TeamId.IsEqual(TeamId, ENameCase::IgnoreCase);
    });
}

int32 ARenegadeTeamCreditsManager::GetTeamCredits(const FName TeamId) const
{
    if (const FRenegadeTeamCreditEntry* Entry = FindEntry(TeamId))
    {
        return Entry->Credits;
    }
    return 0;
}

void ARenegadeTeamCreditsManager::BroadcastCreditChange(const FName TeamId, const int32 PreviousCredits, const int32 NewCredits)
{
    QueueCreditChange(TeamId, PreviousCredits, NewCredits);
    FlushCreditChanges();
}

void ARenegadeTeamCreditsManager::QueueCreditChange(const FName TeamId, const int32 PreviousCredits, const int32 NewCredits)
{
    LastObservedCredits.Add(TeamId, NewCredits);
    FCreditChange Change;
    Change.TeamId = TeamId;
    Change.PreviousCredits = PreviousCredits;
    Change.NewCredits = NewCredits;
    PendingCreditChanges.Add(Change);
}

void ARenegadeTeamCreditsManager::FlushCreditChanges()
{
    if (bDispatchingCreditChanges)
    {
        return;
    }

    TGuardValue<bool> DispatchGuard(bDispatchingCreditChanges, true);
    for (int32 Index = 0; Index < PendingCreditChanges.Num(); ++Index)
    {
        // Copy before invoking user code: a listener may add teams, spend, reset,
        // or destroy the manager. Nested mutations append their notifications.
        const FCreditChange Change = PendingCreditChanges[Index];
        OnTeamCreditsChanged.Broadcast(Change.TeamId, Change.PreviousCredits, Change.NewCredits);
        if (!IsValid(this) || IsActorBeingDestroyed())
        {
            break;
        }
    }
    PendingCreditChanges.Reset();
}

int32 ARenegadeTeamCreditsManager::AddTeamCredits(const FName TeamId, const int32 Amount)
{
    if (!HasAuthority() || TeamId.IsNone() || Amount <= 0)
    {
        return GetTeamCredits(TeamId);
    }

    FRenegadeTeamCreditEntry* Entry = FindMutableEntry(TeamId);
    if (!Entry)
    {
        FRenegadeTeamCreditEntry NewEntry;
        NewEntry.TeamId = TeamId;
        NewEntry.Credits = 0;
        const int32 Index = TeamCredits.Add(NewEntry);
        Entry = &TeamCredits[Index];
    }

    const int32 Previous = Entry->Credits;
    // Widen before adding: signed int32 overflow can otherwise erase the bank.
    Entry->Credits = static_cast<int32>(FMath::Clamp<int64>(static_cast<int64>(Previous) + Amount, 0, MAX_int32));
    ForceNetUpdate();
    BroadcastCreditChange(Entry->TeamId, Previous, Entry->Credits);
    return GetTeamCredits(TeamId);
}

bool ARenegadeTeamCreditsManager::TrySpendTeamCredits(const FName TeamId, const int32 Amount, int32& RemainingCredits)
{
    RemainingCredits = GetTeamCredits(TeamId);
    if (!HasAuthority() || TeamId.IsNone() || Amount <= 0 || RemainingCredits < Amount)
    {
        return false;
    }

    FRenegadeTeamCreditEntry* Entry = FindMutableEntry(TeamId);
    if (!Entry)
    {
        return false;
    }

    const int32 Previous = Entry->Credits;
    Entry->Credits = FMath::Max(0, Previous - Amount);
    RemainingCredits = Entry->Credits;
    ForceNetUpdate();
    BroadcastCreditChange(Entry->TeamId, Previous, Entry->Credits);
    return true;
}

void ARenegadeTeamCreditsManager::SetTeamCredits(const FName TeamId, const int32 NewCredits)
{
    if (!HasAuthority() || TeamId.IsNone())
    {
        return;
    }

    FRenegadeTeamCreditEntry* Entry = FindMutableEntry(TeamId);
    if (!Entry)
    {
        FRenegadeTeamCreditEntry NewEntry;
        NewEntry.TeamId = TeamId;
        NewEntry.Credits = 0;
        const int32 Index = TeamCredits.Add(NewEntry);
        Entry = &TeamCredits[Index];
    }

    const int32 Previous = Entry->Credits;
    Entry->Credits = FMath::Max(0, NewCredits);
    ForceNetUpdate();
    BroadcastCreditChange(Entry->TeamId, Previous, Entry->Credits);
}

void ARenegadeTeamCreditsManager::ResetAllTeamCredits()
{
    if (!HasAuthority())
    {
        return;
    }

    for (FRenegadeTeamCreditEntry& Entry : TeamCredits)
    {
        const int32 Previous = Entry.Credits;
        Entry.Credits = 0;
        if (Previous != 0)
        {
            QueueCreditChange(Entry.TeamId, Previous, 0);
        }
    }
    ForceNetUpdate();
    FlushCreditChanges();
}

void ARenegadeTeamCreditsManager::OnRep_TeamCredits()
{
    TMap<FName, int32> NewObservedCredits;
    for (const FRenegadeTeamCreditEntry& Entry : TeamCredits)
    {
        NewObservedCredits.Add(Entry.TeamId, Entry.Credits);
        const int32 Previous = LastObservedCredits.FindRef(Entry.TeamId);
        if (!LastObservedCredits.Contains(Entry.TeamId) || Previous != Entry.Credits)
        {
            QueueCreditChange(Entry.TeamId, Previous, Entry.Credits);
        }
    }

    // A replicated replacement may remove an entry; retire its cached balance.
    for (const TPair<FName, int32>& Previous : LastObservedCredits)
    {
        if (!NewObservedCredits.Contains(Previous.Key) && Previous.Value != 0)
        {
            FCreditChange Change;
            Change.TeamId = Previous.Key;
            Change.PreviousCredits = Previous.Value;
            Change.NewCredits = 0;
            PendingCreditChanges.Add(Change);
        }
    }
    LastObservedCredits = MoveTemp(NewObservedCredits);
    FlushCreditChanges();
}
