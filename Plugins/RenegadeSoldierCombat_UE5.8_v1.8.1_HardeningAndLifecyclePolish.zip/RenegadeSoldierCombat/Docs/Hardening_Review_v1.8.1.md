# v1.8.1 — Hardening and lifecycle polish

## Scope and release status

This maintenance release is based on the supplied `v1.8.0_GrenadierSoldiers` archive. The review covered all 28 original source/header/build files (19,129 lines), the plugin descriptor, and the existing setup and regression documentation. The focus was concrete correctness, server authority, lifetime management, Blueprint callback safety, numeric integrity, and preserving established gameplay integration.

**This is a source-reviewed maintenance release. Unreal Engine 5.8 is not installed in the review environment. UHT, Unreal compilation, PIE, packaged multiplayer, asset rendering, and performance profiling have not been run here.** The portable checks below exercise selected real source functions through small C++ adapters; they do not emulate Unreal networking, collision, reflection, garbage collection, or Blueprint execution.

## Compatibility contract

- All 196 existing Blueprint callable/pure/event signatures remain available. Existing Blueprint properties and event names are retained.
- Serialized enum definitions/order and the player rifle/pistol/rocket slot enum remain unchanged. Grenadiers remain part of the existing AI weapon system.
- No weapon preset rebalance, content replacement, new plugin dependency, or asset migration is required.
- The Harvester world-space turret solver and the accepted v1.7.13 lateral ground-roll sign remain intact. Presentation refresh now restores the authored baseline before re-caching it.
- All 49 existing replicated properties remain registered; all 24 existing RPCs have implementation definitions. Internal projectile snapshots gain reflection for asset retention, without adding network payload fields.
- Rebuild the plugin from source. Internal native layouts changed, so old compiled plugin binaries must not be mixed with this release.

## Correctness changes

### Soldiers, player control, and projectiles

- Clear local reload state through the shared death/respawn presentation paths. A client killed mid-reload can fire again after respawn.
- Stop local firing and restore captured camera/rotation state when possession is lost, including custom-input use.
- Preserve the mesh's original attachment socket when restoring it from ragdoll.
- Release combat movement ownership before invoking Blueprint resume hooks; avoid stopping navigation that combat never owned.
- Prevent nested player-shot processing through aim, shot, or ammo callbacks, and charge ammunition to the weapon that actually fired.
- Keep server fire-rate tolerance as a bounded early-arrival allowance. It no longer shortens every firing interval and permits a sustained cadence increase.
- Reject non-finite damage and invalid ballistic inputs in the hardened entry points.
- Use wider intermediates for ballistic solving and respect high-arc choice for vertical targets.
- Consume the actual contact fraction of each grenade simulation step and continue the remaining frame after a bounce. Fuse timing no longer loses time on bounce frames.
- Use the swept sphere center for separation after collision, including initial penetration handling, and bound repeated zero-time contacts through the existing bounce limit.
- Remove completed projectile entries before invoking damage callbacks and avoid retaining array references across bounce callbacks. Blueprint callbacks can change or clear projectile arrays safely in those paths.
- Avoid signed overflow when advancing the grenade ID.
- Keep launch-time weapon asset references visible to Unreal garbage collection while projectile or visual snapshots are retained.
- Build the projectile trace ignore list once per update instead of repeating attachment traversal for every simulation step.

### Harvesters, economy, and destination points

- Route manual and automatic unloading through the same guarded deposit operation. Cargo and fractional state are committed before credit callbacks, preventing recursive duplicate payment.
- Widen conversion arithmetic, reject non-finite cargo inputs, and retain cargo that cannot fit in the bank's `int32` balance. A full bank may hold the Harvester in unloading until credits are spent; this preserves undelivered cargo.
- Saturate direct team-credit additions at `2,147,483,647` rather than overflowing the signed balance. Public API signatures and authority restrictions are retained.
- Deliver credit notifications from value snapshots in mutation order. Reset commits all team balances before notifying listeners, and callback-driven array growth cannot invalidate active entries.
- Retire removed entries from the replicated credit observation cache.
- Keep lifecycle duration/state transitions safe against repeated calls and callbacks that change phase or destroy the vehicle.
- Capture the actual spline component/claim name so an existing claim can be released after settings change. Direct harvesting/unloading starts acquire their movement claim.
- Restore authored body/turret rotations before presentation refresh or teardown, avoiding accumulated terrain tilt.
- Validate team compatibility and destroyed Harvester state inside destination reservation entry points. Generic custom actors remain supported as before.
- Make nonexclusive docks behave like nonexclusive harvest points: a successful use does not take exclusive ownership. Existing reservations can still be released after exclusivity is disabled.

### Buildings, defenses, and presentation

- Guard building health operations against non-finite values and arithmetic overflow; keep health percentages and low-health thresholds bounded.
- Cancel a plugin-scheduled owner-removal lifespan when a destroyed building is restored.
- Reject stale/null Harvester destruction notifications and remove the building's destruction binding during teardown.
- Validate deferred-spawn results after Blueprint construction/BeginPlay, and keep factory work from continuing after teardown.
- Avoid transferring a shared Harvester's team or route away from its operational owning Refinery. The enabled single-active-per-team policy also covers different configured Harvester classes.
- Enforce authority inside dock resolution where it mutates assignments, and recheck power for scheduled defensive firing.
- Begin the EVA quiet tail when audio actually finishes, rather than relying on a cue's estimated maximum duration; retain priority interruption and stop the active announcement during world-subsystem teardown.
- Retain and explicitly destroy looping wreck smoke components when the wreck ends play. Niagara wreck smoke uses dedicated, nonpooled ownership for deterministic teardown.
- Reject invalid actors/world-context objects in the Blueprint utility lookup entry points.

## Validation delivered with the source

`Tests/verify_source_contracts.py` checks descriptor/dependency consistency, generated-header include order, replicated-property registration/notification definitions, and RPC implementations. With `--baseline`, it also compares the original Blueprint function signatures and enum definitions.

```text
python Tests/verify_source_contracts.py
python Tests/verify_source_contracts.py --baseline <original-RenegadeSoldierCombat-folder>
```

Portable behavioral harnesses and their exact results are recorded in `Tests/README.md`. They compile selected production code with test adapters under C++ sanitizers. The adapters are outside `Source` and are not part of the Unreal module.

Unreal automation tests are included under `Source/RenegadeSoldierCombat/Private/Tests`, gated by `WITH_DEV_AUTOMATION_TESTS`. Their execution remains pending in UE 5.8. Use **Tools > Test Automation**, select `RenegadeNXT.Hardening`, and run the tests after rebuilding. Epic documents the editor and command-line automation workflow in [Run Automation Tests](https://dev.epicgames.com/documentation/en-us/unreal-engine/run-automation-tests-in-unreal-engine).

## Install and acceptance gates

1. Close Unreal Editor and keep a backup of the currently accepted plugin and project.
2. Replace the project's `Plugins/RenegadeSoldierCombat` directory with the complete release directory. Do not merge old compiled `Binaries`/`Intermediate` outputs into it.
3. Regenerate project files as appropriate and build the UE 5.8 Development Editor target. Resolve any compiler/UHT error before opening gameplay maps.
4. Run the included Unreal automation suite, then the new v1.8.1 section in `Docs/Testing_Checklist.md`.
5. Run the existing Grenadier, rifle, Rocket Officer, player, building, Harvester, EVA, spline, ragdoll, and respawn checks. Test a listen server and remote client; also validate a dedicated server and packaged two-machine session if those are release targets.
6. Profile an extended representative battle in Unreal Insights. Static review and bounded algorithm improvements are not a measured FPS, memory, or network-budget certification.

Keep the accepted baseline available until these project-specific gates pass. Custom Blueprint callbacks, meshes, physics assets, collision profiles, audio cues, and the external spline plugin cannot be validated from this source-only archive.

## API references consulted

The effect cleanup changes follow the documented distinction between automatic cleanup **on effect completion** and explicit component lifetime ownership: [SpawnEmitterAttached](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/UGameplayStatics/SpawnEmitterAttached), [SpawnSystemAttached](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Plugins/Niagara/UNiagaraFunctionLibrary/SpawnSystemAttached). The EVA callback uses the documented audio-finished event: [UAudioComponent](https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Runtime/Engine/UAudioComponent).
