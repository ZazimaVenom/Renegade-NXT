# v1.8.1 regression checks

These checks target defects found in the full v1.8.0 source review. They are deliberately split into portable source/algorithm checks and Unreal Engine tests. **Only the portable checks were executed in the review environment.**

## Results from this review

| Check | Result | What it establishes |
| --- | --- | --- |
| Source contracts against supplied v1.8.0 | PASS | 16 public headers checked; 196 existing Blueprint function signatures preserved; existing Blueprint property/delegate signatures and enum definitions retained; 49 replicated properties registered; 24 RPC implementations present |
| Economy harness, AddressSanitizer | PASS, 6 behavioral groups | Actual production economy methods handle bounds, authority rejection, callback reallocation, nested resets, removed-entry observation, and notification teardown in the adapter environment |
| Economy harness, UndefinedBehaviorSanitizer | PASS, 6 behavioral groups | Same production-method scenarios complete without a reported undefined-behavior violation |
| Projectile harness, AddressSanitizer + UndefinedBehaviorSanitizer | PASS, 20 scenarios / 35 assertions | Selected actual projectile functions pass deterministic fuse/frame-rate, hitch, contact-loop, callback-mutation, ballistic and invalid-target cases |
| Original economy negative controls | Expected failures reproduced | The unchanged v1.8.0 source produces signed overflow near `INT32_MAX` and a heap-use-after-free when a credit callback expands the team array |
| Original projectile negative control | Expected failure reproduced | The unchanged v1.8.0 source fails the bounce-frame time-consumption assertion |
| UE 5.8 UHT / module compilation | NOT RUN | Unreal is unavailable in this environment |
| Included Unreal automation tests | NOT RUN | Execute `RenegadeNXT.Hardening` after compiling in Unreal |
| PIE / packaged networking / project assets / profiling | NOT RUN | Requires the actual Renegade NXT project and assets |

Address checking remained enabled. LeakSanitizer was disabled because this managed environment does not permit its `/proc`/thread inspection; **memory-leak verification is not claimed**.

## Portable commands

Run from the plugin directory. Source checks require Python 3. Behavioral harnesses require Python 3 and a Linux-compatible C++17 `g++` toolchain with sanitizers.

```text
python3 Tests/verify_source_contracts.py
python3 Tests/verify_source_contracts.py --baseline /path/to/original/RenegadeSoldierCombat
python3 Tests/verify_economy.py
python3 Tests/verify_projectiles.py --no-leak-check
```

The economy harness includes the current production `.cpp` and header directly, with small replacement UE containers, actor and delegate types supplied under `economy_shim/`. It never copies or reimplements the production credit methods. Its six groups are scalar/authority behavior, saturation, callback reallocation, atomic nested reset, replicated-cache removals, and destruction during notification dispatch.

The projectile harness extracts the current bodies of `SolveGrenadeBallisticVelocity`, `UpdateActiveGrenadeProjectiles`, `DetonateGrenadeProjectile`, and `UpdatePendingRocketImpacts` into a generated test translation unit. The deterministic physics adapter supplies a floor and zero-time contacts; it is not Unreal collision. It exercises 10/20/30/60/144 FPS, a 0.75-second bounce hitch, the bounce cap, mutation/clearing from callbacks, low/high and vertical arcs, unreachable targets and invalid numeric input.

Both harnesses compile into temporary directories and remove generated source/binaries afterward. Test adapters live outside `Source` and are not linked into the Unreal module. The scripts propagate compile or assertion failures as a nonzero exit code.

The adapter results do **not** verify UHT reflection, Unreal allocator/container implementation, real actor lifetime, Blueprint dispatch, garbage collection, RPC ownership/transport, real collision, presentation, or packaged builds.

### Reproduce the baseline failures

Point these commands at an unmodified copy of the original plugin. Failure is expected for these negative controls:

```text
python3 Tests/verify_economy.py --production-root /path/to/original/RenegadeSoldierCombat --sanitizer undefined --case saturation
python3 Tests/verify_economy.py --production-root /path/to/original/RenegadeSoldierCombat --sanitizer address --case callback_reallocation
python3 Tests/verify_projectiles.py --source-root /path/to/original/RenegadeSoldierCombat --no-leak-check
```

## Unreal automation and project acceptance

Ten development-only automation cases are supplied under `Source/RenegadeSoldierCombat/Private/Tests`:

- Five building cases: finite health/damage, restoration lifespan, low-health/repair policy, stale refinery notifications, and shared Harvester ownership/teardown.
- Two Harvester cases: cargo/bank bounds and presentation refresh/reentrant lifecycle.
- Three support cases: credits/spending/reset, harvest-point reservation, and refinery-dock reservation.

After rebuilding with UE 5.8, open **Tools > Test Automation**, select **RenegadeNXT.Hardening**, and run the suite. For command-line execution, Epic documents `-ExecCmds="Automation RunTest RenegadeNXT.Hardening;Quit"` and `-ReportExportPath="<output path>"` in [Run Automation Tests](https://dev.epicgames.com/documentation/en-us/unreal-engine/run-automation-tests-in-unreal-engine).

Follow with `Docs/Testing_Checklist.md`, including the new v1.8.1 section and every existing gameplay regression. The automation cases do not replace the project-specific multiplayer, spline, ragdoll, projectile-asset GC, audio and extended-battle checks.
