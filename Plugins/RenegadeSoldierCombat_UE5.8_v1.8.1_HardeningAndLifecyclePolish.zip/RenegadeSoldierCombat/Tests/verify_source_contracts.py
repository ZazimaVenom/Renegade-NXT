#!/usr/bin/env python3
"""Portable source/package checks. This does not replace UHT, a UE build, or PIE."""

import argparse
import json
from pathlib import Path
import re
import sys


def uncomment(text):
    return re.sub(r'/\*.*?\*/|//[^\n]*', '', text, flags=re.S)


def macros(text, name):
    """Return metadata and trailing source for a balanced reflection macro."""
    for match in re.finditer(r'\b' + name + r'\s*\(', text):
        start = match.end()
        depth, pos, quoted = 1, start, False
        while depth and pos < len(text):
            ch = text[pos]
            if ch == '"' and text[pos - 1] != '\\':
                quoted = not quoted
            if not quoted:
                depth += (ch == '(') - (ch == ')')
            pos += 1
        if depth:
            raise ValueError(f'Unbalanced {name} macro')
        yield text[start:pos - 1], text[pos:].lstrip()


def normalize(text):
    return re.sub(r'\s+', '', text)


def blueprint_functions(text):
    result = set()
    for meta, tail in macros(text, 'UFUNCTION'):
        if re.search(r'\bBlueprint(?:Callable|Pure|NativeEvent|ImplementableEvent)\b', meta):
            result.add(normalize(re.split(r'[;{]', tail, maxsplit=1)[0]))
    return result


def enums(text):
    return [normalize(match.group(0)) for match in
            re.finditer(r'enum\s+class\s+\w+[^\{]*\{[^}]*\}', text)]


def blueprint_properties(text):
    return {normalize(tail.split(';', 1)[0].split('=', 1)[0])
            for meta, tail in macros(text, 'UPROPERTY')
            if re.search(r'\bBlueprint(?:ReadOnly|ReadWrite|Assignable)\b', meta)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, help='Optional original plugin directory for compatibility checks')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    public = root / 'Source/RenegadeSoldierCombat/Public'
    private = root / 'Source/RenegadeSoldierCombat/Private'
    descriptor = json.loads((root / 'RenegadeSoldierCombat.uplugin').read_text())
    failures = []
    counts = {'headers': 0, 'replicated_properties': 0, 'RPCs': 0, 'baseline_Blueprint_functions': 0}
    if descriptor['Modules'][0]['Name'] != 'RenegadeSoldierCombat':
        failures.append('Runtime module name changed')
    if not any(p['Name'] == 'Niagara' and p['Enabled'] for p in descriptor.get('Plugins', [])):
        failures.append('Niagara dependency is missing')
    cpp_all = uncomment('\n'.join(p.read_text() for p in private.rglob('*.cpp')))
    for header in sorted(public.glob('*.h')):
        raw = header.read_text()
        source = uncomment(raw)
        counts['headers'] += 1
        includes = re.findall(r'^\s*#include\s+"([^"]+)"', source, flags=re.M)
        generated = [value for value in includes if value.endswith('.generated.h')]
        if generated and includes[-1] != generated[-1]:
            failures.append(f'{header.name}: generated header must be the last include')
        class_match = re.search(r'class\s+RENEGADESOLDIERCOMBAT_API\s+(\w+)\s*:', source)
        class_name = class_match.group(1) if class_match else None
        for meta, tail in macros(source, 'UPROPERTY'):
            if re.search(r'\bReplicated(?:Using\s*=\s*\w+)?\b', meta):
                counts['replicated_properties'] += 1
                decl = tail.split(';', 1)[0].split('=', 1)[0].strip()
                prop = re.search(r'(\w+)\s*$', decl).group(1)
                pattern = r'\bDOREPLIFETIME(?:_\w+)?\s*\(\s*' + re.escape(class_name or '') + r'\s*,\s*' + prop + r'\b'
                if not re.search(pattern, cpp_all):
                    failures.append(f'{header.name}: missing lifetime registration for {prop}')
                notify = re.search(r'\bReplicatedUsing\s*=\s*(\w+)', meta)
                if notify and not re.search(r'\b' + re.escape(class_name or '') + r'::' + notify.group(1) + r'\s*\(', cpp_all):
                    failures.append(f'{header.name}: missing RepNotify definition {notify.group(1)}')
        for meta, tail in macros(source, 'UFUNCTION'):
            if re.search(r'\b(?:Server|Client|NetMulticast)\b', meta):
                counts['RPCs'] += 1
                name = re.match(r'[^;{}]*?\b(\w+)\s*\(', tail).group(1)
                if not re.search(r'\b' + re.escape(class_name or '') + r'::' + name + r'_Implementation\s*\(', cpp_all):
                    failures.append(f'{header.name}: missing RPC implementation {name}')
        if args.baseline:
            original = args.baseline / header.relative_to(root)
            if original.exists():
                before = uncomment(original.read_text())
                old_api = blueprint_functions(before)
                counts['baseline_Blueprint_functions'] += len(old_api)
                for removed in sorted(old_api - blueprint_functions(source)):
                    failures.append(f'{header.name}: removed/changed Blueprint signature {removed}')
                for removed in sorted(blueprint_properties(before) - blueprint_properties(source)):
                    failures.append(f'{header.name}: removed/changed Blueprint property {removed}')
                delegate_pattern = r'DECLARE_DYNAMIC_MULTICAST_DELEGATE\w*\s*\([^;]+\);'
                old_delegates = {normalize(value) for value in re.findall(delegate_pattern, before)}
                new_delegates = {normalize(value) for value in re.findall(delegate_pattern, source)}
                if old_delegates - new_delegates:
                    failures.append(f'{header.name}: existing dynamic multicast delegate signature changed')
                if enums(before) != enums(source):
                    failures.append(f'{header.name}: enum definition/order changed')
    for suffix in ('*.o', '*.obj', '*.pyc'):
        if list(root.rglob(suffix)):
            failures.append(f'Build/cache artifacts found: {suffix}')
    print(json.dumps({'status': 'FAIL' if failures else 'PASS', 'version': descriptor['VersionName'],
                      'counts': counts, 'failures': failures,
                      'scope': 'Static source contracts only; not Unreal compilation or runtime validation.'}, indent=2))
    return bool(failures)


if __name__ == '__main__':
    sys.exit(main())
