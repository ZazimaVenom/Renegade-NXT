#pragma once
// UHT/reflection is intentionally outside this standalone test's scope.
