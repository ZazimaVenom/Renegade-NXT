#pragma once
#include "CoreMinimal.h"

struct FLifetimeProperty {};
enum ENetDormancy { DORM_Never };

class AInfo
{
public:
    virtual ~AInfo() = default;
    virtual void BeginPlay() {}
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>&) const {}
    bool HasAuthority() const { return bTestAuthority; }
    bool IsActorBeingDestroyed() const { return bTestDestroyed; }
    void SetReplicateMovement(bool) {}
    void ForceNetUpdate() { ++TestNetUpdateCount; }

    bool bReplicates = false;
    bool bAlwaysRelevant = false;
    ENetDormancy NetDormancy = DORM_Never;
    bool bTestAuthority = true;
    bool bTestDestroyed = false;
    int32 TestNetUpdateCount = 0;
};

// Normally supplied by GENERATED_BODY in the real Unreal build.
#define Super AInfo
