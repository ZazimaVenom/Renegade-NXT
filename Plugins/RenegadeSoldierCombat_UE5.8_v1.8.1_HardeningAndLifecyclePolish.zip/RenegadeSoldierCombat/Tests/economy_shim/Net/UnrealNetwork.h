#pragma once
#define DOREPLIFETIME(...)
