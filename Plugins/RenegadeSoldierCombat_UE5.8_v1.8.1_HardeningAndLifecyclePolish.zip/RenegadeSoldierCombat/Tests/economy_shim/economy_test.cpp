#include "CoreMinimal.h"
#include "GameFramework/Info.h"
#include <iostream>
#include <sstream>
#include <tuple>

// Inspect the replication cache and invoke the actual OnRep implementation only
// inside this standalone translation unit. No production access level is changed.
#define private public
#include "RenegadeTeamCreditsManager.cpp"
#undef private

using Event = std::tuple<std::string, int32, int32>;

static void Check(bool Condition, const std::string& Message)
{
    if (!Condition) throw std::runtime_error(Message);
}

static void Observe(ARenegadeTeamCreditsManager& Manager, std::vector<Event>& Events)
{
    Manager.OnTeamCreditsChanged.Add([&Events](FName Team, int32 Previous, int32 Current)
    {
        Events.emplace_back(Team.ToString(), Previous, Current);
    });
}

static void AddEntry(ARenegadeTeamCreditsManager& Manager, FName Team, int32 Credits)
{
    FRenegadeTeamCreditEntry Entry;
    Entry.TeamId = Team;
    Entry.Credits = Credits;
    Manager.TeamCredits.Add(Entry);
}

static void ScalarAndAuthority()
{
    ARenegadeTeamCreditsManager Manager;
    std::vector<Event> Events;
    Observe(Manager, Events);
    Manager.BeginPlay();
    Check(Manager.GetTeamCredits("GDI") == 0, "missing team starts at zero");
    Check(Manager.AddTeamCredits("GDI", 100) == 100, "initial award");
    Check(Manager.AddTeamCredits("gdi", 50) == 150, "case-insensitive award");
    Check(Manager.TeamCredits.Num() == 1, "case-insensitive team identity");
    int32 Remaining = -1;
    Check(Manager.TrySpendTeamCredits("GDI", 40, Remaining) && Remaining == 110, "successful purchase");
    Check(!Manager.TrySpendTeamCredits("GDI", 111, Remaining) && Remaining == 110, "insufficient credits");
    Check(!Manager.TrySpendTeamCredits("GDI", 0, Remaining) && Remaining == 110, "zero spending rejected");
    Check(!Manager.TrySpendTeamCredits("GDI", -1, Remaining) && Remaining == 110, "negative spending rejected");
    const auto Count = Events.size();
    Check(Manager.AddTeamCredits("GDI", -2) == 110, "negative award rejected");
    Check(Manager.AddTeamCredits("GDI", 0) == 110, "zero award rejected");
    Check(Manager.AddTeamCredits(NAME_None, 100) == 0, "unset team rejected");
    Manager.SetTeamCredits(NAME_None, 100);
    Check(!Manager.TrySpendTeamCredits(NAME_None, 1, Remaining) && Remaining == 0, "unset team spend rejected");
    Check(Events.size() == Count && Manager.TeamCredits.Num() == 1, "invalid calls have no events or entries");
    Manager.SetTeamCredits("Nod", -100);
    Check(Manager.GetTeamCredits("Nod") == 0, "negative balances clamp to zero");
    Manager.SetTeamCredits("Nod", 90);
    Check(Manager.GetTeamCredits("Nod") == 90, "explicit balance");
    Manager.ResetAllTeamCredits();
    Check(Manager.GetTeamCredits("GDI") == 0 && Manager.GetTeamCredits("Nod") == 0, "all balances reset");
    Check(Events[Events.size() - 2] == Event("GDI", 110, 0) && Events.back() == Event("Nod", 90, 0), "reset snapshots");

    Manager.SetTeamCredits("GDI", 73);
    Manager.bTestAuthority = false;
    const auto BeforeClient = Events.size();
    const auto BeforeNetUpdates = Manager.TestNetUpdateCount;
    Check(Manager.AddTeamCredits("GDI", 50) == 73, "client award rejected");
    Check(!Manager.TrySpendTeamCredits("GDI", 1, Remaining) && Remaining == 73, "client spending rejected");
    Manager.SetTeamCredits("GDI", 0);
    Manager.ResetAllTeamCredits();
    Manager.SetTeamCredits("Unknown", 9);
    Check(Manager.GetTeamCredits("GDI") == 73 && Manager.GetTeamCredits("Unknown") == 0, "client mutations leave state unchanged");
    Check(Events.size() == BeforeClient && Manager.TestNetUpdateCount == BeforeNetUpdates, "client mutations emit no event or net update");
}

static void Saturation()
{
    ARenegadeTeamCreditsManager Manager;
    const std::vector<int32> Starts = {0, 1, MAX_int32 / 2, MAX_int32 - 2, MAX_int32 - 1, MAX_int32};
    const std::vector<int32> Awards = {1, 2, 100, MAX_int32 / 2, MAX_int32};
    for (const int32 Start : Starts)
    {
        for (const int32 Award : Awards)
        {
            Manager.SetTeamCredits("GDI", Start);
            const int64 Expected = std::min<int64>(MAX_int32, static_cast<int64>(Start) + Award);
            Check(Manager.AddTeamCredits("GDI", Award) == Expected, "award saturates without signed overflow");
        }
    }
    Manager.SetTeamCredits("GDI", MAX_int32);
    int32 Remaining = -1;
    Check(Manager.TrySpendTeamCredits("GDI", MAX_int32, Remaining) && Remaining == 0, "maximum balance can be spent exactly");
    Check(Manager.AddTeamCredits("GDI", std::numeric_limits<int32>::min()) == 0, "INT32_MIN award rejected");
    Check(!Manager.TrySpendTeamCredits("GDI", std::numeric_limits<int32>::min(), Remaining) && Remaining == 0, "INT32_MIN spend rejected");
    Manager.SetTeamCredits("GDI", std::numeric_limits<int32>::min());
    Check(Manager.GetTeamCredits("GDI") == 0, "INT32_MIN balance clamps safely");
}

static void CallbackReallocation()
{
    ARenegadeTeamCreditsManager Manager;
    std::vector<Event> Events;
    Observe(Manager, Events);
    bool bInjected = false;
    int32 Depth = 0;
    int32 MaximumDepth = 0;
    Manager.OnTeamCreditsChanged.Add([&](FName Team, int32, int32)
    {
        ++Depth;
        MaximumDepth = std::max(MaximumDepth, Depth);
        if (Team == FName("GDI") && !bInjected)
        {
            bInjected = true;
            // Reallocate both production arrays repeatedly while the initial
            // AddTeamCredits call and notification drain remain on the stack.
            for (int32 Index = 0; Index < 512; ++Index)
                Manager.AddTeamCredits(FName("Spawned_" + std::to_string(Index)), 1);
            Manager.AddTeamCredits("GDI", 5);
            int32 Remaining = -1;
            Check(Manager.TrySpendTeamCredits("GDI", 3, Remaining) && Remaining == 12, "nested purchase");
        }
        --Depth;
    });
    Check(Manager.AddTeamCredits("GDI", 10) == 12, "award returns current balance after reentrant callbacks");
    Check(Manager.TeamCredits.Num() == 513, "all callback-created teams retained");
    Check(MaximumDepth == 1, "nested mutations enqueue instead of recursively dispatching");
    Check(Events.size() == 515, "each mutation dispatched exactly once");
    Check(Events.front() == Event("GDI", 0, 10), "outer event is first");
    for (int32 Index = 0; Index < 512; ++Index)
        Check(Events[static_cast<std::size_t>(Index) + 1] == Event("Spawned_" + std::to_string(Index), 0, 1), "nested awards preserve FIFO order");
    Check(Events[513] == Event("GDI", 10, 15) && Events[514] == Event("GDI", 15, 12), "nested same-team snapshots retained");
    Check(Manager.LastObservedCredits.FindRef("GDI") == 12, "cache holds latest reentrant balance");
}

static void AtomicNestedReset()
{
    ARenegadeTeamCreditsManager Manager;
    Manager.SetTeamCredits("Alpha", 100);
    Manager.SetTeamCredits("Beta", 200);
    std::vector<Event> Events;
    Observe(Manager, Events);
    bool bInjected = false;
    Manager.OnTeamCreditsChanged.Add([&](FName Team, int32 Previous, int32 Current)
    {
        if (Team == FName("Alpha") && Previous == 100 && Current == 0 && !bInjected)
        {
            bInjected = true;
            Check(Manager.GetTeamCredits("Alpha") == 0 && Manager.GetTeamCredits("Beta") == 0,
                "reset commits all balances before first listener");
            Manager.AddTeamCredits("Beta", 7);
            Manager.ResetAllTeamCredits();
            Manager.AddTeamCredits("Gamma", 9);
        }
    });
    Manager.ResetAllTeamCredits();
    const std::vector<Event> Expected = {
        {"Alpha", 100, 0}, {"Beta", 200, 0}, {"Beta", 0, 7}, {"Beta", 7, 0}, {"Gamma", 0, 9}
    };
    Check(Events == Expected, "nested reset and awards preserve batch FIFO snapshots");
    Check(Manager.GetTeamCredits("Alpha") == 0 && Manager.GetTeamCredits("Beta") == 0 && Manager.GetTeamCredits("Gamma") == 9,
        "nested changes are retained after outer reset");
    Check(Manager.LastObservedCredits.FindRef("Beta") == 0 && Manager.LastObservedCredits.FindRef("Gamma") == 9,
        "nested reset cache matches final balances");
}

static void ReplicatedCacheAndRemovals()
{
    ARenegadeTeamCreditsManager Manager;
    Manager.bTestAuthority = false;
    AddEntry(Manager, "GDI", 7);
    AddEntry(Manager, "Nod", 11);
    AddEntry(Manager, "Zero", 0);
    Manager.BeginPlay();
    std::vector<Event> Events;
    Observe(Manager, Events);
    bool bCheckedCache = false;
    Manager.OnTeamCreditsChanged.Add([&](FName, int32, int32)
    {
        if (!bCheckedCache)
        {
            bCheckedCache = true;
            Check(!Manager.LastObservedCredits.Contains("Nod") && !Manager.LastObservedCredits.Contains("Zero"),
                "replication replaces cache before listeners");
            Check(Manager.LastObservedCredits.FindRef("GDI") == 10 && Manager.LastObservedCredits.FindRef("New") == 3,
                "replication listener sees complete new cache");
        }
    });
    Manager.TeamCredits.Reset();
    AddEntry(Manager, "GDI", 10);
    AddEntry(Manager, "New", 3);
    Manager.OnRep_TeamCredits();
    Check(Events == std::vector<Event>({{"GDI", 7, 10}, {"New", 0, 3}, {"Nod", 11, 0}}),
        "replicated change, addition and nonzero removal snapshots");
    Manager.OnRep_TeamCredits();
    Check(Events.size() == 3, "unchanged replication is silent");
    Events.clear();
    Manager.TeamCredits.Reset();
    Manager.OnRep_TeamCredits();
    std::sort(Events.begin(), Events.end());
    Check(Events == std::vector<Event>({{"GDI", 10, 0}, {"New", 3, 0}}), "complete removal emits old balances once");
    Check(!Manager.LastObservedCredits.Contains("GDI") && !Manager.LastObservedCredits.Contains("New"), "removed cache entries retired");
    Events.clear();
    AddEntry(Manager, "Nod", 4);
    AddEntry(Manager, "Zero", 0);
    Manager.OnRep_TeamCredits();
    Check(Events == std::vector<Event>({{"Nod", 0, 4}, {"Zero", 0, 0}}), "reintroduced entries start from zero cached balance");
    Check(Manager.TestNetUpdateCount == 0, "manual OnRep simulation performs no authority mutation");
}

static void DestructionStopsDispatch()
{
    ARenegadeTeamCreditsManager Manager;
    Manager.SetTeamCredits("Alpha", 1);
    Manager.SetTeamCredits("Beta", 2);
    std::vector<Event> Events;
    Observe(Manager, Events);
    Manager.OnTeamCreditsChanged.Add([&](FName, int32, int32) { Manager.bTestDestroyed = true; });
    Manager.ResetAllTeamCredits();
    Check(Events.size() == 1, "destruction marker halts queued notifications");
    Check(Manager.GetTeamCredits("Alpha") == 0 && Manager.GetTeamCredits("Beta") == 0,
        "reset committed before destruction listener");
}

int main(int argc, char** argv)
{
    const std::vector<std::pair<std::string, std::function<void()>>> Cases = {
        {"scalar_authority", ScalarAndAuthority}, {"saturation", Saturation},
        {"callback_reallocation", CallbackReallocation}, {"atomic_nested_reset", AtomicNestedReset},
        {"replicated_cache_removals", ReplicatedCacheAndRemovals}, {"destruction_dispatch", DestructionStopsDispatch}
    };
    try
    {
        for (const auto& Case : Cases)
        {
            if (argc > 1 && Case.first != argv[1]) continue;
            Case.second();
            std::cout << "PASS " << Case.first << '\n';
        }
    }
    catch (const std::exception& Error)
    {
        std::cerr << "FAIL " << Error.what() << '\n';
        return 1;
    }
    return 0;
}
