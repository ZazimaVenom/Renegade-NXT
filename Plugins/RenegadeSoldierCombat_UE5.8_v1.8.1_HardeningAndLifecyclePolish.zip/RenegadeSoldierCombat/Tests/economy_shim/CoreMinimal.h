#pragma once

// Standalone behavioral-test substitutes only. These are NOT Unreal headers and
// are never part of the plugin module or an Unreal build.
#include <algorithm>
#include <cctype>
#include <cstdint>
#include <functional>
#include <limits>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

using int32 = std::int32_t;
using int64 = std::int64_t;
constexpr int32 MAX_int32 = std::numeric_limits<int32>::max();

#define USTRUCT(...)
#define UCLASS(...)
#define UPROPERTY(...)
#define UFUNCTION(...)
#define GENERATED_BODY(...)
#define RENEGADESOLDIERCOMBAT_API

enum class ENameCase { IgnoreCase };

class FName
{
public:
    FName() = default;
    FName(const char* InName) : Name(InName) {}
    explicit FName(std::string InName) : Name(std::move(InName)) {}
    bool IsNone() const { return Name.empty() || Canonical() == "none"; }
    bool IsEqual(const FName& Other, ENameCase) const { return *this == Other; }
    bool operator==(const FName& Other) const { return Canonical() == Other.Canonical(); }
    bool operator!=(const FName& Other) const { return !(*this == Other); }
    std::string ToString() const { return Name; }

private:
    std::string Canonical() const
    {
        std::string Result = Name;
        std::transform(Result.begin(), Result.end(), Result.begin(),
            [](unsigned char C) { return static_cast<char>(std::tolower(C)); });
        return Result;
    }
    std::string Name;
};

inline const FName NAME_None;

template <typename T>
class TArray
{
public:
    int32 Num() const { return static_cast<int32>(Items.size()); }
    int32 Add(const T& Item)
    {
        Items.push_back(Item);
        return Num() - 1;
    }
    void Reset() { Items.clear(); }
    T& operator[](int32 Index) { return Items.at(static_cast<std::size_t>(Index)); }
    const T& operator[](int32 Index) const { return Items.at(static_cast<std::size_t>(Index)); }
    auto begin() { return Items.begin(); }
    auto end() { return Items.end(); }
    auto begin() const { return Items.begin(); }
    auto end() const { return Items.end(); }
    template <typename Predicate>
    T* FindByPredicate(Predicate Match)
    {
        const auto Found = std::find_if(Items.begin(), Items.end(), Match);
        return Found == Items.end() ? nullptr : &*Found;
    }
    template <typename Predicate>
    const T* FindByPredicate(Predicate Match) const
    {
        const auto Found = std::find_if(Items.begin(), Items.end(), Match);
        return Found == Items.end() ? nullptr : &*Found;
    }

private:
    std::vector<T> Items;
};

template <typename K, typename V>
struct TPair
{
    K Key;
    V Value;
};

template <typename K, typename V>
class TMap
{
public:
    void Reset() { Items.clear(); }
    void Add(const K& Key, const V& Value)
    {
        for (auto& Item : Items)
        {
            if (Item.Key == Key)
            {
                Item.Value = Value;
                return;
            }
        }
        Items.push_back({Key, Value});
    }
    bool Contains(const K& Key) const
    {
        for (const auto& Item : Items)
            if (Item.Key == Key) return true;
        return false;
    }
    V FindRef(const K& Key) const
    {
        for (const auto& Item : Items)
            if (Item.Key == Key) return Item.Value;
        return V{};
    }
    auto begin() const { return Items.begin(); }
    auto end() const { return Items.end(); }

private:
    std::vector<TPair<K, V>> Items;
};

namespace FMath
{
template <typename T> T Max(T A, T B) { return std::max(A, B); }
template <typename T> T Clamp(T Value, T Minimum, T Maximum)
{
    return std::max(Minimum, std::min(Value, Maximum));
}
}

template <typename T>
class TGuardValue
{
public:
    TGuardValue(T& InValue, T NewValue) : Value(InValue), Previous(InValue) { Value = NewValue; }
    ~TGuardValue() { Value = Previous; }
private:
    T& Value;
    T Previous;
};

template <typename T> auto&& MoveTemp(T& Value) { return std::move(Value); }
template <typename T> bool IsValid(const T* Value) { return Value && !Value->IsActorBeingDestroyed(); }

template <typename... Args>
class TTestMulticastDelegate
{
public:
    void Add(std::function<void(Args...)> Callback) { Callbacks.push_back(std::move(Callback)); }
    void Broadcast(Args... Values)
    {
        // A snapshot supports nested broadcasts without changing the listeners
        // in the active invocation. Real Blueprint delegate dispatch is not tested.
        const auto Snapshot = Callbacks;
        for (const auto& Callback : Snapshot) Callback(Values...);
    }
private:
    std::vector<std::function<void(Args...)>> Callbacks;
};

#define DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(Name, T1, N1, T2, N2, T3, N3) \
    using Name = TTestMulticastDelegate<T1, T2, T3>
