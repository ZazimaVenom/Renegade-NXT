#!/usr/bin/env python3
"""Compile exact production projectile functions against small deterministic UE/physics shims.

This is an isolated algorithm regression harness, not an Unreal build, UHT check, or PIE test.
Requires Python 3 and a C++17 compiler. Binaries and generated C++ stay in a temporary directory.
"""
from pathlib import Path
import argparse
import os
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-root', type=Path, default=Path(__file__).resolve().parents[1],
                    help='Plugin root to test; can point at an original baseline for a negative control.')
parser.add_argument('--compiler', default=os.environ.get('CXX', 'g++'))
parser.add_argument('--no-sanitizers', action='store_true', help='Compile without Address/UndefinedBehaviorSanitizer.')
parser.add_argument('--no-leak-check', action='store_true', help='Disable only leak detection when ptrace/container restrictions prevent it.')
args = parser.parse_args()
root = args.source_root.resolve()
s=(root/'Source/RenegadeSoldierCombat/Private/RenegadeSoldierCombatComponent.cpp').read_text()
def extract(name):
    i=s.index('URenegadeSoldierCombatComponent::'+name+'(')
    i=s.rfind('\n',0,i)+1
    start=s.index('{',i); depth=1;j=start+1
    while depth:
        if s[j]=='{': depth+=1
        elif s[j]=='}':depth-=1
        j+=1
    return s[i:j]
preamble=r'''
#include <algorithm>
#include <cmath>
#include <vector>
#include <functional>
#include <stdexcept>
#include <iostream>
#include <limits>
#include <cassert>
using int32=int;
constexpr float KINDA_SMALL_NUMBER=.0001f;
#define SCENE_QUERY_STAT(x) 0
namespace FMath {
template<class T> T Max(T a,T b){return std::max(a,b);}
template<class T> T Min(T a,T b){return std::min(a,b);}
template<class T> T Clamp(T x,T a,T b){return std::clamp(x,a,b);}
template<class T> bool IsFinite(T x){return std::isfinite(x);}
template<class T> T Abs(T x){return std::abs(x);}
template<class T> T Sqrt(T x){return std::sqrt(x);}
template<class T> bool IsNearlyZero(T x){return std::abs(x)<KINDA_SMALL_NUMBER;}
}
struct FVector {double X=0,Y=0,Z=0; FVector()=default;FVector(double x,double y,double z):X(x),Y(y),Z(z){}
 FVector operator+(FVector b) const{return {X+b.X,Y+b.Y,Z+b.Z};}
 FVector operator-(FVector b) const{return {X-b.X,Y-b.Y,Z-b.Z};}
 FVector operator*(double a) const{return {X*a,Y*a,Z*a};}
 FVector operator/(double a) const{return *this*(1/a);}
 bool ContainsNaN()const{return !std::isfinite(X)||!std::isfinite(Y)||!std::isfinite(Z);}
 double Size()const{return std::sqrt(X*X+Y*Y+Z*Z);}
 bool IsNearlyZero()const{return Size()<KINDA_SMALL_NUMBER;}
 FVector GetSafeNormal()const{return IsNearlyZero()?FVector():*this/Size();}
 static double DotProduct(FVector a,FVector b){return a.X*b.X+a.Y*b.Y+a.Z*b.Z;}
 static double Distance(FVector a,FVector b){return (a-b).Size();}
 static const FVector ZeroVector,UpVector;
};
const FVector FVector::ZeroVector={0,0,0}; const FVector FVector::UpVector={0,0,1};
FVector operator*(double a,FVector b){return b*a;}
struct AActor {bool valid=true;};
template<class T> bool IsValid(T* p){return p && p->valid;}
struct FHitResult {float Time=1,Distance=0,PenetrationDepth=0;bool bStartPenetrating=false,bBlockingHit=false;FVector Location,ImpactPoint,ImpactNormal;AActor* GetActor()const{return nullptr;}};
struct FCollisionQueryParams {bool bReturnPhysicalMaterial=false;FCollisionQueryParams(int,bool,AActor*){}};
struct FCollisionObjectQueryParams {FCollisionObjectQueryParams(int){}};
struct FCollisionShape {float Radius;static FCollisionShape MakeSphere(float r){return {r};}};
struct FQuat {static const FQuat Identity;};const FQuat FQuat::Identity={};
struct FColor {static const FColor Orange,Cyan;};const FColor FColor::Orange={},FColor::Cyan={};
template<class...T>void DrawDebugLine(T...){}
enum class EAllowShrinking {No};
template<class T>struct TArray {std::vector<T> v;int Num()const{return v.size();}bool IsValidIndex(int i)const{return i>=0&&i<Num();}T& operator[](int i){return v.at(i);}const T& operator[](int i)const{return v.at(i);}void RemoveAtSwap(int i,int,EAllowShrinking){v.at(i)=v.back();v.pop_back();}void Reset(){v.clear();}};
enum class ERenegadeGrenadeDetonationMode{Impact,TimedBounce};
struct FRenegadeGrenadeLauncherSettings {float MaximumFlightSeconds=5,TimedFuseSeconds=1.25,MaximumSimulationStepSeconds=.025,GravityScale=1,CollisionRadius=4,BounceFriction=.2,BounceRestitution=.5,MinimumBounceSpeed=20,DebugDrawDuration=0,ProjectileSpeed=1600;int MaximumBounces=4;bool bDrawDebugGrenade=false,bUseHighArc=false;ERenegadeGrenadeDetonationMode DetonationMode=ERenegadeGrenadeDetonationMode::TimedBounce;};
struct FRenegadeWeaponSettings {FRenegadeGrenadeLauncherSettings GrenadeLauncher;int TraceChannel=0,CombatTargetObjectType=0;bool bUseCombatTargetObjectTraceFallback=false;};
struct FRenegadeGrenadeProjectileRuntimeState {int GrenadeId=1;FVector Position={0,0,40},Velocity={100,0,-600};float ElapsedSeconds=0;int BounceCount=0;bool bSettled=false;FRenegadeWeaponSettings Weapon;};
struct WeakActor{AActor* p=nullptr;AActor* Get()const{return p;}};
struct FRenegadePendingRocketImpactRuntimeState{float ElapsedSeconds=0,DurationSeconds=.1;FRenegadeWeaponSettings Weapon;FVector ImpactLocation={3,4,5};WeakActor DirectHitActor;FHitResult DirectHit;};
struct UWorld {float Gravity=-980;bool forceContact=false;float GetGravityZ()const{return Gravity;}
 bool SweepSingleByChannel(FHitResult& h,FVector a,FVector b,FQuat,int,FCollisionShape sh,FCollisionQueryParams){
 if(!forceContact&&b.Z>sh.Radius)return false;
 h.bBlockingHit=true;h.ImpactNormal=FVector::UpVector;
 h.Time=forceContact?0:float(std::clamp((a.Z-sh.Radius)/(a.Z-b.Z),0.0,1.0));
 h.Location=a+(b-a)*h.Time;h.ImpactPoint=h.Location-FVector(0,0,sh.Radius);h.Distance=FVector::Distance(a,h.Location);return true;}
 bool SweepSingleByObjectType(FHitResult&,FVector,FVector,FQuat,FCollisionObjectQueryParams,FCollisionShape,FCollisionQueryParams){return false;}
};
struct URenegadeHarvesterCombatComponent {AActor* GetOwner(){return nullptr;}};
struct URenegadeBuildingCombatComponent {AActor* GetOwner(){return nullptr;}};
struct URenegadeSoldierCombatComponent;
namespace RenegadeCombatPrivate {void AddOwnerHierarchyToTraceIgnore(AActor*,FCollisionQueryParams&){}URenegadeSoldierCombatComponent* ResolveCombatComponentFromActorHierarchy(AActor*){return nullptr;}URenegadeHarvesterCombatComponent* ResolveHarvesterComponentFromActorHierarchy(AActor*){return nullptr;}URenegadeBuildingCombatComponent* ResolveBuildingComponentFromActorHierarchy(AActor*){return nullptr;}URenegadeBuildingCombatComponent* ResolveRegisteredBuildingAtImpactLocation(UWorld*,FVector,float){return nullptr;}}
struct URenegadeSoldierCombatComponent {bool valid=true;AActor owner;UWorld world;TArray<FRenegadeGrenadeProjectileRuntimeState> ActiveGrenadeProjectiles;TArray<FRenegadePendingRocketImpactRuntimeState>PendingRocketImpacts;int explosions=0,bounces=0,rocketExplosions=0;FVector lastImpact;std::function<void()>onBounce,onExplosion,onRocket;
 bool HasAuthority()const{return true;}UWorld*GetWorld()const{return const_cast<UWorld*>(&world);}AActor*GetOwner(){return &owner;}bool HasBegunPlay(){return valid;}
 bool IsGrenadeLauncherWeapon(const FRenegadeWeaponSettings&)const{return true;}
 bool SolveGrenadeBallisticVelocity(const FRenegadeWeaponSettings&,const FVector&,const FVector&,FVector&,float&)const;
 void UpdateActiveGrenadeProjectiles(float);void UpdatePendingRocketImpacts(float);
 void DetonateGrenadeProjectile(int,const FVector&,const FVector&,AActor*,const FHitResult&);
 void ApplyGrenadeExplosionDamage(const FRenegadeWeaponSettings&,const FVector& p,AActor*,const FHitResult&){++explosions;lastImpact=p;if(onExplosion)onExplosion();}
 void ApplyRocketExplosionDamage(const FRenegadeWeaponSettings&,const FVector& p,AActor*,const FHitResult&){++rocketExplosions;lastImpact=p;if(onRocket)onRocket();}
 void MulticastGrenadeExploded(int,FVector,FVector){}
 void MulticastGrenadeBounced(int,FVector,FVector,FVector){++bounces;if(onBounce)onBounce();}
};
'''
tests=r'''
int assertionCount=0;
void require(bool condition,const char* message){++assertionCount;if(!condition)throw std::runtime_error(message);}
int main(){try{
 for(float dt: {0.1f,0.05f,1.f/30,1.f/60,1.f/144}){
   URenegadeSoldierCombatComponent c;c.ActiveGrenadeProjectiles.v.emplace_back();float t=0;
   while(c.explosions==0&&t<4){c.UpdateActiveGrenadeProjectiles(dt);t+=dt;}
   require(c.explosions==1,"timed grenade detonates once");
   require(t>=1.25f-0.001f&&t<=1.25f+dt+0.001f,"grenade fuse follows wall time at all tested frame rates");
 }
 {URenegadeSoldierCombatComponent c;c.ActiveGrenadeProjectiles.v.emplace_back();c.UpdateActiveGrenadeProjectiles(.75f);require(std::abs(c.ActiveGrenadeProjectiles[0].ElapsedSeconds-.75f)<.001f,"bounce hitch consumes full frame time");}
 {URenegadeSoldierCombatComponent c;c.world.forceContact=true;c.ActiveGrenadeProjectiles.v.emplace_back();c.ActiveGrenadeProjectiles[0].Weapon.GrenadeLauncher.MaximumBounces=32;c.ActiveGrenadeProjectiles[0].Weapon.GrenadeLauncher.MinimumBounceSpeed=0;c.ActiveGrenadeProjectiles[0].Weapon.GrenadeLauncher.BounceRestitution=1;c.ActiveGrenadeProjectiles[0].Weapon.GrenadeLauncher.BounceFriction=0;c.UpdateActiveGrenadeProjectiles(2);require(c.bounces==32&&c.explosions==1,"zero-time contacts are bounded and fuse continues");}
 {URenegadeSoldierCombatComponent c;c.ActiveGrenadeProjectiles.v.resize(3);c.onExplosion=[&]{c.ActiveGrenadeProjectiles.Reset();c.valid=false;};c.UpdateActiveGrenadeProjectiles(2);require(c.explosions==1,"damage callback clears grenade array safely");}
 {URenegadeSoldierCombatComponent c;c.PendingRocketImpacts.v.resize(3);c.onRocket=[&]{c.PendingRocketImpacts.Reset();c.valid=false;};c.UpdatePendingRocketImpacts(1);require(c.rocketExplosions==1&&c.lastImpact.Z==5,"damage callback clears rocket array safely");}
 {URenegadeSoldierCombatComponent c;c.ActiveGrenadeProjectiles.v.emplace_back();bool appended=false;c.onBounce=[&]{if(!appended){appended=true;for(int i=0;i<100;i++){FRenegadeGrenadeProjectileRuntimeState v;v.GrenadeId=10+i;c.ActiveGrenadeProjectiles.v.push_back(v);}}};c.UpdateActiveGrenadeProjectiles(.75f);require(std::abs(c.ActiveGrenadeProjectiles[0].ElapsedSeconds-.75f)<.001f,"bounce callback reallocates live array safely");}
 {URenegadeSoldierCombatComponent c;FRenegadeWeaponSettings w;w.GrenadeLauncher.MaximumFlightSeconds=10;FVector velocity;float seconds;
 for(bool high:{false,true})for(FVector target:{FVector(1000,0,0),FVector(0,0,100),FVector(0,0,-100),FVector(300,0,200)}){
  w.GrenadeLauncher.bUseHighArc=high;require(c.SolveGrenadeBallisticVelocity(w,FVector(),target,velocity,seconds),"reachable ballistic solution exists");FVector arrived=velocity*seconds+FVector(0,0,.5*c.world.Gravity*seconds*seconds);require(FVector::Distance(arrived,target)<.02,"ballistic solution arrives at target");if(high&&target.X==0)require(velocity.Z>0,"vertical high arc launches upward");}
 w.GrenadeLauncher.bUseHighArc=false;require(!c.SolveGrenadeBallisticVelocity(w,FVector(),FVector(100000,0,10000),velocity,seconds),"unreachable target rejected");require(!c.SolveGrenadeBallisticVelocity(w,FVector(),FVector(std::numeric_limits<double>::quiet_NaN(),0,0),velocity,seconds),"NaN target rejected");}
 std::cout<<"PASS: 20 scenarios, "<<assertionCount<<" assertions (fuse/frame-rate, hitch, bounded contacts, callback mutation, ballistics and invalid targets)\n";
}catch(const std::exception& e){std::cerr<<"FAIL after "<<assertionCount<<" assertions: "<<e.what()<<"\n";return 1;}}
'''
body='\n'.join(extract(n) for n in ['SolveGrenadeBallisticVelocity','UpdateActiveGrenadeProjectiles','DetonateGrenadeProjectile','UpdatePendingRocketImpacts'])
with tempfile.TemporaryDirectory(prefix='renegade-projectile-tests-') as temporary_directory:
    path = Path(temporary_directory) / 'projectile_harness.cpp'
    executable = Path(temporary_directory) / 'projectile_harness'
    path.write_text(preamble + body + tests, encoding='utf-8')
    command = [args.compiler, '-std=c++17', '-O1', '-g']
    if not args.no_sanitizers:
        command += ['-fsanitize=address,undefined', '-fno-omit-frame-pointer']
    command += [str(path), '-o', str(executable)]
    subprocess.run(command, check=True)
    environment = os.environ.copy()
    if args.no_leak_check:
        environment['ASAN_OPTIONS'] = environment.get('ASAN_OPTIONS', '') + ':detect_leaks=0'
    subprocess.run([str(executable)], check=True, env=environment)
