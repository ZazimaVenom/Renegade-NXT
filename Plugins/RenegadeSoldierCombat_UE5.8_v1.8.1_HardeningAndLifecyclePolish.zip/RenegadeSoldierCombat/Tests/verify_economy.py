#!/usr/bin/env python3
"""Compile and exercise the ACTUAL economy implementation with minimal UE shims.

Usage (Python 3 and g++ required):
    python3 Tests/verify_economy.py
    python3 Tests/verify_economy.py --sanitizer undefined --case saturation

The test translation unit includes the production .cpp/header directly. No credit
method is copied or reimplemented. Reflection, actor lifetime, networking, UE
containers, and Blueprint multicast delivery are replaced by small test doubles.
Consequently a pass is behavioral coverage, NOT an Unreal compilation, UHT,
Blueprint, garbage-collection, network-replication, PIE or packaged-build test.
An Unreal Engine 5.8 build and runtime checks remain necessary.
"""

import argparse
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--compiler", default="g++")
    parser.add_argument("--sanitizer", choices=("both", "address", "undefined", "none"), default="both")
    parser.add_argument("--case", choices=("scalar_authority", "saturation", "callback_reallocation", "atomic_nested_reset", "replicated_cache_removals", "destruction_dispatch"))
    parser.add_argument("--production-root", type=Path, help="Optional alternate plugin root; test shim always comes from this release.")
    args = parser.parse_args()
    compiler = shutil.which(args.compiler)
    if not compiler:
        parser.error(f"C++ compiler not found: {args.compiler}")

    tests = Path(__file__).resolve().parent
    root = (args.production_root or tests.parent).resolve()
    module = root / "Source" / "RenegadeSoldierCombat"
    if not (module / "Private" / "RenegadeTeamCreditsManager.cpp").is_file():
        parser.error(f"Production economy source not found under {root}")
    sanitizers = ("address", "undefined") if args.sanitizer == "both" else (args.sanitizer,)
    env = os.environ.copy()
    # LeakSanitizer requires /proc thread access unavailable in some managed
    # containers. Address checks stay enabled; this harness does not test leaks.
    env["ASAN_OPTIONS"] = "detect_leaks=0:halt_on_error=1:abort_on_error=1"
    env["UBSAN_OPTIONS"] = "halt_on_error=1:print_stacktrace=1"
    with tempfile.TemporaryDirectory(prefix="renegade-economy-") as temp:
        for sanitizer in sanitizers:
            executable = Path(temp) / f"economy-{sanitizer}"
            command = [compiler, "-std=c++17", "-g", "-O1", "-Wall", "-Wextra", "-Werror", "-fno-omit-frame-pointer"]
            if sanitizer != "none":
                command += [f"-fsanitize={sanitizer}", "-fno-sanitize-recover=all"]
            # Non-PIE avoids occasional ASan shadow mapping collisions in Linux
            # container environments; supported by the documented g++ toolchain.
            command += ["-fno-pie", "-no-pie", "-I", str(tests / "economy_shim"), "-I", str(module / "Public"), "-I", str(module / "Private"), str(tests / "economy_shim" / "economy_test.cpp"), "-o", str(executable)]
            print(f"Compiling actual production economy source ({sanitizer})...", flush=True)
            subprocess.run(command, check=True, env=env)
            run = [str(executable)] + ([args.case] if args.case else [])
            subprocess.run(run, check=True, env=env)
    print("PASS standalone economy behavior; Unreal Engine build/runtime validation remains required.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except subprocess.CalledProcessError as error:
        raise SystemExit(error.returncode if error.returncode > 0 else 1)
